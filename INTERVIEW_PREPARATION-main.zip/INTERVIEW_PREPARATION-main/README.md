# INTERVIEW_PREPARATION

Reactjs Edurekha Interview Questions:
https://www.edureka.co/blog/interview-questions/react-interview-questions/

Rakesh Interviews 
====================
https://github.com/sudheerj/reactjs-interview-questions#what-is-react

https://stackblitz.com/edit/web-platform-ipksee?file=script.js
